first copy rar file into this folder. then...
double click rarCrack.exe.then follow instructions well.
then wait for extracting files and it will show you correct password.
if you pc is slow down press ctrl + c and the find last password count and next time use it for start


if program not tart at begining.then open unrar32bit folder and run rarCrack.exe

(Assessin KB sri lanka)